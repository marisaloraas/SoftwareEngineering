/**
 *
 * @author SUN
 */
public class TestDriver {

    public static void main(String[] args){
        System.out.println("StackDecorator1 Test:");
        Stack mystack = new StackDecorator1(new StackImpl1());
        mystack.push(10);
        mystack.push(20);
        mystack.top();
        mystack.pop();
        mystack.isEmpty();
        System.out.println("StackDecorator2 Test:");
       Stack mystack2 = new StackDecorator2(new StackImpl1());
        mystack2.push(10);
        mystack2.top();
        mystack2.pop();
        mystack2.pop();
        mystack2.top();
        mystack2.isEmpty();
    }

}