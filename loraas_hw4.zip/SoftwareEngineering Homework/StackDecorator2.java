/**
 * Assingmet 4: Design Patterns and OOD
 * Software Engineering
 *
 * @title StackDecorator2.java
 * @author Marisa Loraas
 * @date 4/12/2021
 * @brief This class is the first decorator class for the StackImpl1.java and Stack.java interfaces.
 * This class prints out if the function the user would like to invoke is possible or not. Prints
 * TRUE if it is and FALSE if they function cannot be invoked.
 */

public class StackDecorator2 implements Stack{
    public Stack mystack;
    //my max array size from the StackImpl1.java class
    public int MAX = 1000;
    public StackDecorator2(Stack stack){
        super();
        this.mystack = stack;
    }

    @Override
    public void push(int i) {
        if(this.mystack.top > MAX - 1)
            System.out.println("FALSE");
        else {
            this.mystack.push(i);
            System.out.println("TRUE");
        }
    }

    @Override
    public int pop() {
        if(this.mystack.isEmpty())
            System.out.println("FALSE");
        else{
            System.out.println("TRUE");
        }
        return this.mystack.pop();
    }

    @Override
    public int top() {
        if(this.mystack.isEmpty())
            System.out.println("FALSE");
        else{
            System.out.println("TRUE");
        }
        return this.mystack.top();
    }

    @Override
    public boolean isEmpty() {
        //You should always be able to check if a stack is empty, so alwasy True here
        System.out.println("TRUE");
        return this.mystack.isEmpty();
    }
}
