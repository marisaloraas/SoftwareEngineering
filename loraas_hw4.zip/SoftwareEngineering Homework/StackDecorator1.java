/**
 * Assingmet 4: Design Patterns and OOD
 * Software Engineering
 *
 * @title StackDecorator1.java
 * @author Marisa Loraas
 * @date 4/12/2021
 * @brief This class is the first decorator class for the StackImpl1.java and Stack.java interfaces.
 * This class prints out the function the user invokes and completes the function from the
 * StackImpl1.java class.
 */

public class StackDecorator1 implements Stack {
    public Stack mystack;

    public StackDecorator1(Stack stack){
        super();
        this.mystack = stack;
    }

    @Override
    public void push(int i) {
        this.mystack.push(i);
        System.out.println("push()");
    }

    @Override
    public int pop(){
        System.out.println("pop()");
        return this.mystack.pop();
    }

    @Override
    public int top() {
        System.out.println("top()");
        return this.mystack.top();
    }

    @Override
    public boolean isEmpty() {
        System.out.println("isEmpty()");
        return this.mystack.isEmpty();
    }
}

