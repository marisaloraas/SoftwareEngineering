/**
 *
 * @author SUN
 */
public interface Stack {

    public int top = -1;

    public void push (int i);

    public int pop ();

    public int top ();

    public boolean isEmpty();

}