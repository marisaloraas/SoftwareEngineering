/**
 * Assingmet 4: Design Patterns and OOD
 * Software Engineering
 *
 * @title StackImpl1.java
 * @author Marisa Loraas
 * @date 4/12/2021
 * @brief This class implements a stack from the Stack.java interface given for
 * assignment 4. It implements the 4 functions from the interface: push pop top and isEmpty
 */

public class StackImpl1 implements Stack {
    public int top;
    public int[] stack_array;

    public StackImpl1(){
        super();
        this.top = -1;
        this.stack_array = new int[1000];
    }

    public void push (int i){
        if (this.top >= stack_array.length - 1)
            System.out.println("Error: Stack Overflow");
          else
              stack_array[++this.top] = i;
    }

    public int pop(){
        if (this.top < 0){
            //System.out.println("Error: Stack is Empty");
            return -1;
        }else{
            int temp = this.top;
            --this.top;
            return this.stack_array[temp];
        }
    }

    public int top(){
        if (this.top < 0){
            //System.out.print("Error: Stack is Empty");
            return -1;
        }else
            return this.stack_array[this.top];
    }

    public boolean isEmpty(){
        return (this.top < 0);
    }
}
